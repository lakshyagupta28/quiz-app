package com.telusko.quizapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuizappApplicationTests {

	@Test
	void contextLoads() {
	}

}
